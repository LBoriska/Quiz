﻿using Microsoft.Win32;
using System;
using System.Windows.Forms;
using System.IO;
using ServiceStack;

namespace Quiz
{
    public partial class Form1 : Form
    {
        private DataBaseQuiz db = new
            DataBaseQuiz();
        private string log;
        //private List<Land> liL;
        public Form1()
        {
            InitializeComponent();
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {
            radioButtonLand.Checked = true;
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            if (radioButtonLand.Checked == true)
            {
                Form2 form = new Form2();
                form.ShowDialog();
            }
            else if (radioButtonHauptst.Checked == true) 
            {
                MessageBox.Show("Noch nicht fertig. Wir bitten um Entschuldigen\n und Verständnis. Versuchen Sie doch mit Flagge.",
                    "MessageBox mit zwei Zeilen");
                //Form  form = new Form ();
                //form.ShowDialog();
            }
            else if (radioButtonFlagge.Checked == true)
            {
                Form4 form = new Form4();
                form.ShowDialog();
            }
        }
       
    }//public partial class Form1 : Form
}
