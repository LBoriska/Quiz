﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quiz
{
    public class Land
    {
        private int l_id;
        private string l_land;
        private string hauptstadt;

        public int L_id { get => l_id; set => l_id = value; }
        public string L_land { get => l_land; set => l_land = value; }
        public string Hauptstadt { get => hauptstadt; set => hauptstadt = value; }

        public Land() { }
        public Land ( int lid, string ll,string hs)
        {
            L_id = lid;
            L_land = ll;
            Hauptstadt = hs;

        }
    }
}
