﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quiz
{
    public partial class Form3 : Form
    {
        private List<Spieler> liSp;

        DataBaseQuiz db = new DataBaseQuiz();

        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            liSp = db.getSpieler();
            dataGridView1.Rows.Clear();
            foreach (Spieler si in liSp)
            {
                dataGridView1.Rows.Add(si.S_id.ToString(), si.S_login,
                    si.S_punkte.ToString());
            }
           
        }
    }
}
