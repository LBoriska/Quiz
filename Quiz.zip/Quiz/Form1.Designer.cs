﻿namespace Quiz
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelWas = new System.Windows.Forms.Label();
            this.radioButtonLand = new System.Windows.Forms.RadioButton();
            this.radioButtonHauptst = new System.Windows.Forms.RadioButton();
            this.radioButtonFlagge = new System.Windows.Forms.RadioButton();
            this.buttonStart = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelWas
            // 
            this.labelWas.AutoSize = true;
            this.labelWas.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.labelWas.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelWas.Location = new System.Drawing.Point(243, 153);
            this.labelWas.Name = "labelWas";
            this.labelWas.Size = new System.Drawing.Size(266, 24);
            this.labelWas.TabIndex = 4;
            this.labelWas.Text = "Was möchten Sie überprüfen?";
            // 
            // radioButtonLand
            // 
            this.radioButtonLand.AutoSize = true;
            this.radioButtonLand.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.radioButtonLand.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonLand.Location = new System.Drawing.Point(214, 231);
            this.radioButtonLand.Name = "radioButtonLand";
            this.radioButtonLand.Size = new System.Drawing.Size(70, 28);
            this.radioButtonLand.TabIndex = 5;
            this.radioButtonLand.Text = "Land";
            this.radioButtonLand.UseVisualStyleBackColor = false;
            // 
            // radioButtonHauptst
            // 
            this.radioButtonHauptst.AutoSize = true;
            this.radioButtonHauptst.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.radioButtonHauptst.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonHauptst.Location = new System.Drawing.Point(326, 231);
            this.radioButtonHauptst.Name = "radioButtonHauptst";
            this.radioButtonHauptst.Size = new System.Drawing.Size(116, 28);
            this.radioButtonHauptst.TabIndex = 5;
            this.radioButtonHauptst.Text = "Hauptstadt";
            this.radioButtonHauptst.UseVisualStyleBackColor = false;
            // 
            // radioButtonFlagge
            // 
            this.radioButtonFlagge.AutoSize = true;
            this.radioButtonFlagge.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.radioButtonFlagge.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonFlagge.Location = new System.Drawing.Point(466, 231);
            this.radioButtonFlagge.Name = "radioButtonFlagge";
            this.radioButtonFlagge.Size = new System.Drawing.Size(87, 28);
            this.radioButtonFlagge.TabIndex = 5;
            this.radioButtonFlagge.Text = "Flagge";
            this.radioButtonFlagge.UseVisualStyleBackColor = false;
            // 
            // buttonStart
            // 
            this.buttonStart.BackColor = System.Drawing.SystemColors.Info;
            this.buttonStart.Location = new System.Drawing.Point(326, 337);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(104, 44);
            this.buttonStart.TabIndex = 6;
            this.buttonStart.Text = "START";
            this.buttonStart.UseVisualStyleBackColor = false;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Quiz.Properties.Resources.London;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonStart);
            this.Controls.Add(this.radioButtonFlagge);
            this.Controls.Add(this.radioButtonHauptst);
            this.Controls.Add(this.radioButtonLand);
            this.Controls.Add(this.labelWas);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label labelWas;
        private System.Windows.Forms.RadioButton radioButtonLand;
        private System.Windows.Forms.RadioButton radioButtonHauptst;
        private System.Windows.Forms.RadioButton radioButtonFlagge;
        private System.Windows.Forms.Button buttonStart;
    }
}

