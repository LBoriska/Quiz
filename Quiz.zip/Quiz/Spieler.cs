﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quiz
{
    public class Spieler
    {
        private int s_id;
        private string s_login;
        private int s_punkte;

        public int S_id { get => s_id; set => s_id = value; }
        public string S_login { get => s_login; set => s_login = value; }
        public int S_punkte { get => s_punkte; set => s_punkte = value; }

        public Spieler() { }

        public Spieler (int id, string log, int pu)
        {
            S_id = id;
            S_login = log;
            S_punkte = pu;
        }
    }
}
