﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quiz
{
    public partial class Form2 : Form
    {
        private List<Land> selectedLands;
        private List<RadioButton> liRb = new List<RadioButton>();
        private List<RadioButton> liFlagge= new List<RadioButton>();
        DataBaseQuiz db = new DataBaseQuiz();
        private int zahl;
        private int gameCount;

        public Form2()
        {
            InitializeComponent();
            gameCount = 0;
            zahl= 0;
        }

        
        private void InitializeGame()
        {
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            radioButton4.Checked = false;

            
            radioButton5.BackgroundImage= null;
            radioButton6.BackgroundImage= null;
            radioButton7.BackgroundImage= null;
            radioButton8.BackgroundImage= null;

            radioButton5.Checked = false;
            radioButton6.Checked = false;
            radioButton7.Checked = false;
            radioButton8.Checked = false;

            if (gameCount >= 10)
            {    
                

                MessageBox.Show ($"Das Spiel ist beendet! Anzahl der richtigen Antworten: {zahl}");
                this.Close();
               if (tbLogin.Text.Length > 0)
                {
                    db.saveSpieler(tbLogin.Text, zahl);
                }

                showMessageBoxPunkte();
                return;

                // db.saveSpieler(Form1.tbLogin.Text, zahl);
            }
            gameCount++;
            labelGameCount.Text = $"Spiel Nr {gameCount}";
            
            selectedLands = GetRandomLands(); // get random  land von list
            // Выбираем first страну из all
            labelDasLand.Text = selectedLands[0].L_land; // land in labelDasLand

            // liFlagge für Flagge erstellen

            liFlagge.Add(radioButton5);
            liFlagge.Add (radioButton6);
            liFlagge.Add (radioButton7);
            liFlagge.Add (radioButton8);

            // liste radioButtons für Hauptstädt

            liRb.Add(radioButton1);
            liRb.Add(radioButton2);
            liRb.Add(radioButton3);
            liRb.Add(radioButton4);


            Random rd = new Random();
            int index = rd.Next(0, 4);

            foreach (RadioButton r in liRb)
            { r.Text = ""; }

            liRb[index].Text = selectedLands[0].Hauptstadt; // Haupstadt des ausgewählten Landes in 
            liFlagge[index].Image = Image.FromFile("Bilder_flagge_eur\\" + selectedLands[0].L_land + ".png");                                                // в рандомную радиобатон
            
            index = 1;
            foreach (RadioButton r in liRb)
            {
                if (r.Text == "")
                {
                    r.Text = selectedLands[index].Hauptstadt;
                    index++;
                }
            }
            index = 1;
            foreach (RadioButton p in liFlagge)
            {
                if (p.Image == null)
                {
                    p.Image = Image.FromFile("Bilder_flagge_eur\\" + selectedLands[index].L_land + ".png");
                    index++;
                }
            }



        }//InitializeGame

        private void checkAntwort()  // vergleicht die Aantwort und die Richtige
        {

            foreach (RadioButton r in liRb)
            {
                if (r.Checked == true && r.Text == selectedLands[0].Hauptstadt)
                    zahl++;
            }

            foreach (RadioButton p in liFlagge)
            {
                if (p.Checked == true && p.Image == Image.FromFile("Bilder_flagge_eur\\" + selectedLands[0].L_land + ".png"))
                    zahl++;
            }

            label1.Text = zahl.ToString();  
        }//checkAntwort()

        private void showMessageBoxPunkte()
        {
            DialogResult result = MessageBox.Show("Möchten Sie alle Ergebnisse sehen? ",
               "MessageBox mit YesNo", MessageBoxButtons.YesNo );
            if (result == DialogResult.Yes)
            {
                Form3 form = new Form3();
                form.ShowDialog();
            }
            else if (result == DialogResult.No)
            {
                MessageBox.Show("Dann Aufwiedersehen!", "MessageBox mit No");
            }
        }//private void showMessageBoxPunkte()


        // random 4 Länder
        private List<Land> GetRandomLands()
        {
            List<Land> selectedLands = db.getLand();
            return selectedLands;
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            InitializeGame();
            checkAntwort();

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton rb = (RadioButton)sender;
            if (rb.Checked == true
            && rb.Text == selectedLands[0].Hauptstadt)
                zahl++;

            label1.Text = zahl.ToString();

        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {

        }

        
    }
}
