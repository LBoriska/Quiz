﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quiz
{
    
    public class DataBaseQuiz
    {
      private MySqlConnection con = null;

        public DataBaseQuiz ()
        {
            con = new MySqlConnection ("SERVER=localhost;UID=root;PASSWORD='root';DATABASE=quiz");
        }
        private void oeffnen()
        {

            con.Open();
        }
        private void schliessen()
        {
            if (con != null)
                con.Close();
        }
        public List<Land> getLand()
        {
            List<Land> liLand = new List<Land>();
            oeffnen();
            MySqlCommand com = con.CreateCommand ();
            com.CommandText = "SELECT * FROM land ORDER by rand() LIMIT 4;";
            MySqlDataReader reader = com.ExecuteReader ();
            while (reader.Read())
            {
                liLand.Add(new Land(
                    reader.GetInt32(0), //L_ID
                    reader.GetString(1),//land
                    reader.GetString(2)));//stadt
                
            }
             schliessen();
             return liLand;
        }//public List<Land> getLand()

        public List<Spieler> getSpieler()  // ORDER BY Punkte
        {
            List<Spieler> liSp = new List<Spieler>();
            oeffnen();
            MySqlCommand com = con.CreateCommand();
            com.CommandText = "SELECT * FROM spieler ORDER BY punkte DESC;";
            MySqlDataReader reader = com.ExecuteReader ();
            while (reader.Read())
            {
                liSp.Add(new Spieler(
                    reader.GetInt32(0), // S_ID
                    reader.GetString(1), //Login
                    reader.GetInt32(2) //Punkte
                    ));
            }
            return liSp;
        }// public List<Spieler> getSpieler()

        public void saveSpieler (string log, int punkt) // Speichert Spieler in db
        {
            oeffnen();
            

            string s = string.Format
                ("INSERT INTO spieler (login, punkte) VALUES ('{0}', '{1}');",
                log, punkt);
            MySqlCommand com = con.CreateCommand();
            com.CommandText = s;
            com.ExecuteNonQuery ();

            schliessen();

        }

        

    }
}
