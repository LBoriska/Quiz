﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using Image = System.Drawing.Image;
using RadioButton = System.Windows.Forms.RadioButton;

namespace Quiz
{
    public partial class Form4 : Form
    {
        private List<Land> selectedLands;
        private List<RadioButton> liRbHaupt = new List<RadioButton>();
        DataBaseQuiz db = new DataBaseQuiz();
        private int zaehler;
        private int gameCount;
        public Form4()
        {
            InitializeComponent();
            gameCount = 0;
            zaehler = 0;
        }
        private void InitializeGame() 
        {

            radioButton1.Checked = false; //Hauptst.
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            radioButton4.Checked = false;
            pictureBoxDieFlagge.Image = null;

            if (gameCount >= 10)
            {
                MessageBox.Show($"Das Spiel ist beendet! Anzahl der richtigen Antworten: {zaehler}");
                this.Close();
                if (labelGameCount.Text.Length > 0)
                {
                    db.saveSpieler(labelGameCount.Text, zaehler);
                }

                showMessageBoxPunkte();
                return;

            }
            gameCount++;
            labelGameCount.Text = $"Spiel Nr {gameCount}";

            selectedLands = GetRandomLands();
            pictureBoxDieFlagge.Image = Image.FromFile("Bilder_flagge_eur\\" + selectedLands[0].L_land + ".png");

            liRbHaupt.Add(radioButton1);
            liRbHaupt.Add(radioButton2);
            liRbHaupt.Add(radioButton3);
            liRbHaupt.Add(radioButton4);

            Random rd = new Random();
            int index = rd.Next(0, 4);

            foreach (RadioButton r in liRbHaupt)
            { r.Text = ""; }
            liRbHaupt[index].Text = selectedLands[0].Hauptstadt;

            index = 1;
            foreach (RadioButton r in liRbHaupt)
            {
                if (r.Text == "")
                {
                    r.Text = selectedLands[index].Hauptstadt;
                    index++;
                }
            }
        }//InitializeGame
        private void checkAntwort()
        {
            foreach (RadioButton r in liRbHaupt)
            {
                if (r.Checked == true && r.Text == selectedLands[0].Hauptstadt)
                    zaehler++;
            }
            label1.Text = zaehler.ToString();
        }//checkAntwort()
        private List<Land> GetRandomLands()
        {
            List<Land> selectedLands = db.getLand();
            return selectedLands;
        }
        private void showMessageBoxPunkte()
        {
            DialogResult result = MessageBox.Show("Möchten Sie alle Ergebnisse sehen? ",
               "MessageBox mit YesNo", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                Form3 form = new Form3();
                form.ShowDialog();
            }
            else if (result == DialogResult.No)
            {
                MessageBox.Show("Dann Auf Wiedersehen!", "MessageBox mit No");
            }
        }//private void showMessageBoxPunkte()

        private void btnCheck_Click(object sender, EventArgs e)
        {
            InitializeGame();
            checkAntwort();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }//Form4 : Form
}
